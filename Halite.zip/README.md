Acest README contine informatii despre configurarea, compilarea si abordarea algoritmica a botului nostru de joc Halite, numit „MyBot”. Acesta a fost scris de echipa formata din:
- Ailiesei Ana-Maria
- Ivana Stefania
- Olteanu Andreea-Denisa

Pentru compilare se va folosi Python 3.x si environment-ul aflat pe site-ul jocului.

## Pasi
Instalati Python 3.x pe computer daca nu este deja instalat.
Clonati sau descarcati mediul Halite de pe site-ul oficial al jocului.
Plasati codul cu implementarea pentru bot in directorul corespunzator din mediul Halite.

## Detalii de compilare
Botul este scris in Python si nu necesita regula de build, dar are regula de run si clean in Makefile.

## Algoritmi și strategii
- Cautare cel mai apropiat inamic
Folosim un algoritm de cautare pentru a identifica directia cea mai apropiata a inamicului dintr-un patrat dat, limitata de regiunea vizibila a hartii jocului.

## Calcul euristic
Botul calculeaza o euristica pentru fiecare miscare, luand in considerare raporturile productie/putere si daunele potentiale.

## Atacuri în cooperare
Am implementat o metoda pentru a detecta daca un atac in cooperare a unor patratele asupra unui patratel al inamicului este posibil si benefic, pentru a maximiza sansele de a captura teritoriul inamic.

## Raspuns dinamic
Pe baza starii jocului, botul nostru decide fie sa se extinda agresiv, fie sa-si consolideze puterea, adaptandu-si strategia in functie de starea hartii si a inamicului.

# Strategii pentru etapa a treia:

## Confruntarea cu mai mulți boti
In etapa a treia, unde trebuie sa ne confruntam cu mai multi boti simultan, am adoptat urmatoarele strategii aditionale:
- Planificare dinamica si managementul resurselor
- Am incercat sa imbunatattim functia de potential initial pentru a lua în considerare atat productia cat si proximitatea fata de inamici, astfel încat sa prioritizam expansiunea strategica si atacurile eficiente.
- Implementarea unei functii de degradare a potentialului pe baza distantei, pentru a directiona mai eficient miscarile spre tintele cu valoare ridicată.
- Coordonarea atacurilor multiple
- Am introdus liste de "must still" (red light) si "must go" (green light) pentru a gestiona mai eficient atacurile coordonate. Astfel, putem stabili ce patratele trebuie sa ramana pe loc pentru a asigura coerenta atacurilor si ce patratele sunt pregatite sa avanseze.
- Adaptare în timp real
- Folosim strategii de incercuire pentru a limita miscarile inamicilor si pentru a prelua controlul asupra teritoriilor strategice.

## Analiza complexitatii
Algoritmul botului ruleaza in principal in complexitatea timpului O(n) per miscare, unde n este numarul de patrațele pe care le controleaza. Decizia de mutare a fiecarui patrat este independenta de celelalte, dar ia în considerare starea globala (cum ar fi latimea/inaltimea hartii si proximitatea inamicului).

## Surse de inspiratie
Acest bot a fost inspirat de diverse strategii si modele de bot disponibile la https://halite-tournament.fly.dev/documentation/next_steps/. Am analizat diferite strategii si am combinat aspecte ale expansiunii agresive si ale formarii defensive, adaptate pentru a raspunde dinamic la schimbarea starii jocului. In plus, pentru cea de-a treia etapa am cautat si repository-uri pe git, iar pentru implementare am analizat strategiile folosite. Paginile de git dupa care ne-am inspirat sunt urmatoarele: https://github.com/jenheilemann/Halite-I-Bot si https://github.com/veden/Halite-bot-2016/blob/master/MyBot.java.

## Impartirea task-urilor
Pentru scrierea codului am avut urmatoarele task-uri pentru fiecare membru al echipei:

- Implementarea algoritmilor de cautare si optimizarea procesului de decizie de mutare.
- Lucrul la logica de atac cooperativ a patratelelor si integrarea evaluarilor euristice pentru deciziile de mutare.
- Ocuparea de testare, depanare si perfectionare a strategiilor pe baza rezultatelor jocului si a comportamentului adversarului.