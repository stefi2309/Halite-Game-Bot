import sys
from collections import namedtuple
from itertools import chain, zip_longest
import random



def grouper(iterable, n, fillvalue=None):
    "Collect data into fixed-length chunks or blocks"
    # grouper('ABCDEFG', 3, 'x') --> ABC DEF Gxx"
    args = [iter(iterable)] * n
    return zip_longest(*args, fillvalue=fillvalue)


NORTH, EAST, SOUTH, WEST, STILL = range(5)


def opposite_cardinal(direction):
    "Returns the opposing cardinal direction."
    return (direction + 2) % 4 if direction != STILL else STILL


Square = namedtuple('Square', 'x y owner strength production')

Move = namedtuple('Move', 'square direction')



# def get_direction_from_coordinates(source: Square, x, y):
#     if (source.y < y):
#         snd_dir = WEST if (source.x > x) else (EAST if (source.x < x) else SOUTH)
#         return random.choice((SOUTH, snd_dir))
#     elif (source.y > y):
#         snd_dir = WEST if (source.x > x) else (EAST if (source.x < x) else NORTH)
#         return random.choice((NORTH, snd_dir))
#     elif (source.x > x):
#         return WEST
#     elif (source.x < x):
#         return EAST
#     return STILL

class GameMap:
    def __init__(self, size_string, production_string, map_string=None):
        self.width, self.height = tuple(map(int, size_string.split()))
        self.production = tuple(tuple(map(int, substring)) for substring in grouper(production_string.split(), self.width))
        self.contents = None
        self.get_frame(map_string)
        self.starting_player_count = len(set(square.owner for square in self)) - 1

    def get_frame(self, map_string=None):
        "Updates the map information from the latest frame provided by the Halite game environment."
        if map_string is None:
            map_string = get_string()
        split_string = map_string.split()
        owners = list()
        while len(owners) < self.width * self.height:
            counter = int(split_string.pop(0))
            owner = int(split_string.pop(0))
            owners.extend([owner] * counter)
        assert len(owners) == self.width * self.height
        assert len(split_string) == self.width * self.height
        self.contents = [[Square(x, y, owner, strength, production)
                          for x, (owner, strength, production)
                          in enumerate(zip(owner_row, strength_row, production_row))]
                         for y, (owner_row, strength_row, production_row)
                         in enumerate(zip(grouper(owners, self.width),
                                          grouper(map(int, split_string), self.width),
                                          self.production))]

    def __iter__(self):
        "Allows direct iteration over all squares in the GameMap instance."
        return chain.from_iterable(self.contents)

    def neighbors(self, square, n=1, include_self=False):
        "Iterable over the n-distance neighbors of a given square.  For single-step neighbors, the enumeration index provides the direction associated with the neighbor."
        assert isinstance(include_self, bool)
        assert isinstance(n, int) and n > 0
        if n == 1:
            combos = ((0, -1), (1, 0), (0, 1), (-1, 0), (0, 0))   # NORTH, EAST, SOUTH, WEST, STILL ... matches indices provided by enumerate(game_map.neighbors(square))
        else:
            combos = ((dx, dy) for dy in range(-n, n+1) for dx in range(-n, n+1) if abs(dx) + abs(dy) <= n)
        return (self.contents[(square.y + dy) % self.height][(square.x + dx) % self.width] for dx, dy in combos if include_self or dx or dy)

    def get_target(self, square, direction):
        "Returns a single, one-step neighbor in a given direction."
        dx, dy = ((0, -1), (1, 0), (0, 1), (-1, 0), (0, 0))[direction]
        return self.contents[(square.y + dy) % self.height][(square.x + dx) % self.width]

    def get_distance(self, sq1, sq2):
        "Returns Manhattan distance between two squares."
        dx = min(abs(sq1.x - sq2.x), sq1.x + self.width - sq2.x, sq2.x + self.width - sq1.x)
        dy = min(abs(sq1.y - sq2.y), sq1.y + self.height - sq2.y, sq2.y + self.height - sq1.y)
        return dx + dy
    
    def get_square_at(self, x, y):
        "Returns the square at the given coordinates."
        return self.contents[y][x]
    
    def get_direction(self, source: Square, destination: Square):
        x = destination.x
        y = destination.y
        distx = source.x - x
        disty = source.y - y

        if (distx == 0 and disty == 0):
            return STILL

        if (distx < 0 and abs(distx) > abs(distx + self.width)):
            distx += self.width
        elif (distx > 0 and distx > abs(self.width - distx)):
            distx = self.width - distx

        if (disty < 0 and abs(disty) > abs(disty + self.height)):
            disty += self.height
        elif (disty > 0 and disty > abs(self.height - disty)):
            disty = self.width - disty

        if (disty < 0):
            if abs(distx) > abs(disty):
                return WEST if (distx > 0) else EAST
            
            return SOUTH
        elif (disty > 0):
            if abs(distx) > abs(disty):
                return WEST if (distx > 0) else EAST
            
            return NORTH
        
        return WEST if (distx > 0) else EAST

        


#################################################################
# Functions for communicating with the Halite game environment  #
#################################################################


def send_string(s):
    sys.stdout.write(s)
    sys.stdout.write('\n')
    sys.stdout.flush()


def get_string():
    return sys.stdin.readline().rstrip('\n')


def get_init():
    playerID = int(get_string())
    m = GameMap(get_string(), get_string())
    return playerID, m


def send_init(name):
    send_string(name)


def translate_cardinal(direction):
    "Translate direction constants used by this Python-based bot framework to that used by the official Halite game environment."
    return (direction + 1) % 5


def send_frame(moves):
    send_string(' '.join(str(move.square.x) + ' ' + str(move.square.y) + ' ' + str(translate_cardinal(move.direction)) for move in moves))